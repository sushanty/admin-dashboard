// import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpResponse, HttpErrorResponse } from '@angular/common/http';
// import { observable, throwError, Observable, BehaviorSubject } from 'rxjs';
// import { catchError, retry, switchMap, filter, take } from 'rxjs/operators';
// import { CustomErrorHandler } from './customErrorHandler';
// import { AuthService } from 'src/app/services/auth.service';
// import { Injectable } from '@angular/core';
// import { LoaderService } from '../../services/loader.service';
// import swal from 'sweetalert';
// import { ErrorResponse } from 'src/app/home/Modals/errorResponse.modal';
// import { AppConstants } from '../Constants/constants';
// import { AppToastrService } from 'src/app/services/ToastrService/toastr.service';



// @Injectable()
// export class HttpErrorInterceptor implements HttpInterceptor {

//     private isRefreshing = false;
//     private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);

//     constructor(private _authservice: AuthService,
//         private _toastrService: AppToastrService,
//         private _loaderservice: LoaderService) { }

//     intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

//         const token = this._authservice.getToken();
//         if (token) {
//             request = this.addToken(request, token);
//         }

       
//     //     return next.handle(request).pipe(catchError(error => {
//     //          if (error instanceof HttpErrorResponse && error.status === 401) { return this.handle401Error(request, next);
//     //         } else {
//     //             return throwError(error);
//     //         }
//     //     }));
//     // }

//     private addToken(request: HttpRequest<any>, token: string) {
//         return request.clone({
//             setHeaders: {
//                 'Authorization': `Bearer ${token}`
//             }
//         });
//     }

//     private handle401Error(request: HttpRequest<any>, next: HttpHandler) {
//         if (!this.isRefreshing) {
//             this.isRefreshing = true;
//             this.refreshTokenSubject.next(null);

//             return this.authService.refreshToken().pipe(
//                 switchMap((token: any) => {
//                     this.isRefreshing = false;
//                     this.refreshTokenSubject.next(token.jwt);
//                     return next.handle(this.addToken(request, token.jwt));
//                 }));

//         } else {
//             return this.refreshTokenSubject.pipe(
//                 filter(token => token != null),
//                 take(1),
//                 switchMap(jwt => {
//                     return next.handle(this.addToken(request, jwt));
//                 }));
//         }
//     }



//     // private isRefreshing = false;
//     // private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);

//     // constructor(private _authservice: AuthService,
//     //             private _toastrService: AppToastrService,
//     //             private _loaderservice: LoaderService) { }

//     // intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {


//     //   // tslint:disable-next-line:no-debugger
//     //   debugger;

//     //   const token = this._authservice.getToken();
//     //   if (token) {
//     //     request = this.addToken(request, token);
//     //   }


//     //     return next.handle(request)
//     //         .pipe(
//     //             //retry(1),
//     //             catchError((error: HttpErrorResponse) => {
//     //                 const errorMessage = new ErrorResponse();
//     //                 if (error.error instanceof ErrorEvent) {
//     //                     // client-side error
//     //                     errorMessage.message = error.error.message;
//     //                 } else {
//     //                     // server-side error
//     //                     errorMessage.statusCode = error.status;
//     //                     errorMessage.message = error.message;
//     //                     // debugger;
//     //                     // alert(error.status);
//     //                     if (error.status === 401) {
//     //                         this._authservice.collectFailedRequest(request);
//     //                         console.log('failed request:' + JSON.stringify(request));   
//     //                         this.handle401Error(request, next);                        
//     //                     }
//     //                     // else {
//     //                     //     return next.handle(this._authservice.getFailedRequest());
//     //                     // }
//     //                 }

//     //                 return throwError(errorMessage);
//     //             })
//     //         );
//     // }

//     // addToken(request: HttpRequest<any>, token: any): HttpRequest<any> {
//     //     return request.clone({
//     //         setHeaders: {
//     //           'Authorization': `Bearer ${token}`
//     //         }
//     //       });
//     // }

//     // handle401Error(request: HttpRequest<any>, next: HttpHandler): any {
//     //    debugger
//     //     swal({
//     //         title: 'Token expired!',
//     //         text: 'Click ok to refresh the token to continue.',
//     //         icon: 'warning'
//     // })
//     // .then((willRefresh) => {
//     //   if (willRefresh) {
//     //     // swal('Token is refreshed. ', {
//     //     //   icon: 'success',
//     //     // });
//     //     if (!this.isRefreshing) {
//     //         this.isRefreshing = true;
//     //         this.refreshTokenSubject.next(null);
//     //     }
//     //     // this._authservice.renewExpiredToken().subscribe(res => {
//     //     //   console.log('new access token:' + res[AppConstants.ACCESS_TOKEN]);
//     //     //   console.log('new refresh token:' + res[AppConstants.REFRESH_TOKEN]);
//     //     //   if (res['accessToken'] !== '') {
//     //     //     this._authservice.saveRefreshToken(res[AppConstants.REFRESH_TOKEN]);
//     //     //     this._toastrService.showSuccess('Token refreshed', '');
//     //     //     return next.handle(this._authservice.getFailedRequest());



//     //     //   }
//     //     // });
//     //     this._authservice.renewExpiredToken().pipe(
//     //         switchMap((token: any) => {
//     //             this.isRefreshing = false;
//     //             console.log('new token:' + token);
//     //             this.refreshTokenSubject.next(token[AppConstants.ACCESS_TOKEN]);
//     //             return next.handle(this.addToken(request, token[AppConstants.ACCESS_TOKEN]));
//     //         }));
//     //   } else {
//     //     //swal('Token is not refreshed. Please log in again to continue.');
//     //     return this.refreshTokenSubject.pipe(
//     //         filter(token => token != null),
//     //         take(1),
//     //         switchMap(jwt => {
//     //             return next.handle(this.addToken(request, jwt));
//     //         }));
//     //   }
//     // });

//     // }

//     // // onrefreshtoken(request: HttpRequest<any>, next: HttpHandler) {
//     // //     return next.handle(this._authservice.getFailedRequest());
//     // //    }
// }

//------------------------------------------------------------------------------------------------------------------------

import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { AuthService } from 'src/app/services/auth.service';
import { Observable, throwError, BehaviorSubject } from 'rxjs';
import { catchError, filter, take, switchMap, flatMap } from 'rxjs/operators';

import { LoaderService } from '../../services/loader.service';
import swal from 'sweetalert';
import { ErrorResponse } from 'src/app/home/Modals/errorResponse.modal';
import { AppConstants } from '../Constants/constants';
import { AppToastrService } from 'src/app/services/ToastrService/toastr.service';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {

  private isRefreshing = false;
  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor(public authService: AuthService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (this.authService.getToken()) {
      request = this.addToken(request, this.authService.getToken());
    }

    // return next.handle(request).pipe(catchError(error => {
    //   if (error instanceof HttpErrorResponse && error.status === 401) {
    //     return this.handle401Error(request, next);
    //   } else {
    //     return throwError(error);
    //   }
    // }));
// tslint:disable-next-line:no-debugger
debugger; 
    return next.handle(request)
    .pipe(
       //retry(1),
        catchError((error: HttpErrorResponse) => {
            const errorMessage = new ErrorResponse();
           if (error.error instanceof ErrorEvent) {
               // client-side error
               errorMessage.message = error.error.message;
            } else {
                // server-side error
                errorMessage.statusCode = error.status;
               errorMessage.message = error.message;
               // debugger;
                // alert(error.status);
                if (error.status === 401) {
                  //  this._authservice.collectFailedRequest(request);
                   console.log('failed request:' + JSON.stringify(request));
                    this.handle401Error(request, next);
                }
                // else {
                //     return next.handle(this._authservice.getFailedRequest());
                // }
            }

           return throwError(errorMessage);
       })
    );

  }

  private addToken(request: HttpRequest<any>, token: string): HttpRequest<any> {
    return request.clone({
      setHeaders: {
        'Authorization': `Bearer ${token}`
      }
    });
  }

  private handle401Error(request: HttpRequest<any>, next: HttpHandler) {
      // tslint:disable-next-line:no-debugger
      debugger;

    //   swal({
    //                 title: 'Token expired!',
    //                 text: 'Click ok to refresh the token to continue.',
    //                 icon: 'warning'
          //  }).then((refresh) => {
              //  swal('the returned value is :' + refresh);
              //  if (refresh) {
                    // if (!this.isRefreshing) {
                    //     this.isRefreshing = true;
                    //     this.refreshTokenSubject.next(null);
                  
                        //  this.authService.renewExpiredToken().subscribe(data => {
                        //     console.log('last failed request:' + JSON.stringify( request));
                        //     if (data['accessToken'] !== '') {
                        //         this.authService.saveRefreshToken(data[AppConstants.REFRESH_TOKEN]);
                        //       return  next.handle(this.addToken(request, data['accessToken'] ));
                        //     }
                           
                        // });


                        this.authService.renewExpiredToken().pipe(flatMap(result => {
                            alert(result['accessToken'] );
                            return next.handle(this.addToken(request, result['accessToken'] ));
                        }));
                        // .pipe(
                        //   switchMap((token: any) => {
                        //     this.isRefreshing = false;
                        //     this.refreshTokenSubject.next(token.jwt);
                        //     return next.handle(this.addToken(request, token.jwt));
                        //   }));
                  
                    //   } else {
                    //     return this.refreshTokenSubject.pipe(
                    //       filter(token => token != null),
                    //       take(1),
                    //       switchMap(jwt => {
                    //         return next.handle(this.addToken(request, jwt));
                    //       }));
                    //   }
               // }
           // });
        }
  }


