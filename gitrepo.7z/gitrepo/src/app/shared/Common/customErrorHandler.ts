export class CustomErrorHandler {
    public code: number;
    public message: string;
}
