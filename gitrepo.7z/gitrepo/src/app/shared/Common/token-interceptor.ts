import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpHeaders,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';

import {Observable, of, from, BehaviorSubject, throwError } from 'rxjs';
import { map, filter, take, switchMap, catchError } from 'rxjs/operators';
import { AuthService } from '../../services/auth.service';
import { AppConstants } from '../Constants/constants';
import swal from 'sweetalert';
import { AppToastrService } from 'src/app/services/ToastrService/toastr.service';


@Injectable()
export class TokenInterceptor implements HttpInterceptor {
   //  constructor(private _authservice: AuthService) {}

    // intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // //   let token: string = localStorage.getItem('app-token') != null ?  localStorage.getItem('app-token').replace('"', '') : '';

    // //  token = token != null ? token.replace('"', '') : '';
    // //  console.log('interceptor token: ' + token);
    // const token = this._authservice.getToken();
    //   if (token) {
    //       request = request.clone({ headers: request.headers.set('Authorization', 'Bearer ' + token) });
    //   }

    //   if (!request.headers.has('Content-Type')) {
    //       request = request.clone({ headers: request.headers.set('Content-Type', 'application/json') });
    //   }

    //   request = request.clone({ headers: request.headers.set('Accept', 'application/json') });

    //   return next.handle(request);
    // //   .pipe(
    // //       map((event: HttpEvent<any>) => {
    // //           if (event instanceof HttpResponse) {
    // //               console.log('event--->>>', event);
    // //           }
    // //           return event;
    // //       }));
    // }

    private isRefreshing = false;
  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);

  constructor(public authService: AuthService, private _toastrService: AppToastrService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (this.authService.getToken()) {
      request = this.addToken(request, this.authService.getToken());
    }

    return next.handle(request).pipe(catchError(error => {
     // alert(error.status);
      if (error instanceof HttpErrorResponse && error.status === 401) {
        return this.handle401Error(request, next);
      } else {
        return throwError(error);
      }
    }));
  }

  private addToken(request: HttpRequest<any>, token: string) {
    return request.clone({
      setHeaders: {
        'Authorization': `Bearer ${token}`
      }
    });
  }

  private handle401Error(request: HttpRequest<any>, next: HttpHandler) {

    // swal('Click on either the button or outside the modal.')
    // .then((value) => {
    //  if (value) {

    //  }
    // });
    if (!this.isRefreshing) {
      this.isRefreshing = true;
      this.refreshTokenSubject.next(null);
     // alert('hmmmm');
      return this.authService.renewExpiredToken().pipe(
        switchMap((data: any) => {
          if (data[AppConstants.ACCESS_TOKEN] !== '') {
            this.authService.saveRefreshToken(data[AppConstants.REFRESH_TOKEN]);
          }
          this.isRefreshing = false;
          this.refreshTokenSubject.next(data[AppConstants.ACCESS_TOKEN]);
          this._toastrService.showSuccess('Token refreshed.', 'Great.');
          return next.handle(this.addToken(request, data[AppConstants.ACCESS_TOKEN]));
        }));

    } else {
      return this.refreshTokenSubject.pipe(
        filter(token => token != null),
        take(1),
        switchMap(jwt => {
          return next.handle(this.addToken(request, jwt));
        }));
    }
  }

}
