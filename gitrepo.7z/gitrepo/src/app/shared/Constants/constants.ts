export class AppConstants {
    public static readonly REGISTER_MODAL_TITLE = 'Registration Form';
    public static readonly REGISTER_SUCCESS_MESSAGE = 'Registration successful.';
    public static readonly REGISTER_FAILED_MESSAGE = 'Registration failed.';
    public static readonly FORGOTPASSWORD_MODAL_TITLE = 'Reset Password';
    public static readonly FORGOTPASSWORD_SUCCESS_MESSAGE = 'Password reset successful.';
    public static readonly FORGOTPASSWORD_FAILED_MESSAGE = 'Password reset failed.';
    public static readonly FORGOTPASSWORD_HELPTEXT = 'Please enter same email ID that you used for registration.';
    public static readonly ACCESS_TOKEN = 'accessToken';
    public static readonly REFRESH_TOKEN = 'refreshToken';
    // public static readonly LOGIN_NAME = 'loginname';
    // public static readonly PASSWORD = 'password';
}

export class RouterConstants {
    public static readonly HOME = '/home';
    public static readonly LOGIN = '/login';
}

export class UrlConstants {
    public static readonly GET_ALL_USERS = 'https://localhost:44393/users/all';
    public static readonly GET_RENEWED_ACCESS_TOKEN = 'https://localhost:44393/auth/refreshtoken';
    public static readonly AUTH_LOGIN = 'https://tracker-236412.appspot.com/login/Authenticate';
    //' http://localhost:49389/login/Authenticate';
   
    public static readonly Login_getUsers = 'https://tracker-236412.appspot.com/login/list';
    
    public static readonly Login_getUsersbyId = 'https://tracker-236412.appspot.com/login/users/{1}';
}
