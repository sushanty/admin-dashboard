import { TestBed } from '@angular/core/testing';

import { NgxspinnerService } from './ngxspinner.service';

describe('NgxspinnerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NgxspinnerService = TestBed.get(NgxspinnerService);
    expect(service).toBeTruthy();
  });
});
