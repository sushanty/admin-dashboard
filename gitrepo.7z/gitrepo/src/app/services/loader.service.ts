import { Injectable } from '@angular/core';
// import {NgxSpinnerService} from 'ngx-spinner';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {

  constructor(
   // private _spinnerservice: NgxSpinnerService
    ) { }

  showSpinner() {
   // this._spinnerservice.show();
  }
  hideSpinner() {
  //  this._spinnerservice.hide();
  }
}
