import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Users } from '../home/Modals/user.modal';
import { UrlConstants } from '../shared/Constants/constants';
import { Observable, throwError } from 'rxjs';
import {map, catchError } from 'rxjs/operators';
// import 'rxjs/add/operator/catch';

@Injectable({
  providedIn: 'root'
})
export class UsersService implements OnInit {
  constructor(
    private _http: HttpClient
  ) { }

  ngOnInit(): void {
  }


//   return this.http.get(environment.API_URL + 'list/supervise/' + encodeURIComponent(id),
//   {headers: new HttpHeaders().set('Authorization', `Bearer ${localStorage.getItem('id_token')}`)}).pipe(
//     map((res: any) => res.data)
// );


  loadUsers(): Observable<Users> {
   return this._http.get<Users>(UrlConstants.GET_ALL_USERS
    // ,
    // {headers: new HttpHeaders().set('Authorization', `Bearer ${localStorage.getItem('app-token')}`)}
    );
    // .pipe(
    //   map((resp: any) => resp.data)
    //   );
                    

  }

  errorHandler(error: HttpErrorResponse) {
    return Observable.throw(error.message || 'unexpected error occured.');

  }

}
