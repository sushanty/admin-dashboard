import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Users } from '../home/Modals/user.modal';
import { UrlConstants } from '../shared/Constants/constants';
import { Observable, throwError } from 'rxjs';
import {map, catchError } from 'rxjs/operators';
import { Login } from '../Entity/login';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor( private _http: HttpClient) { }

  login(logincredentials: Login) {
  
     return this._http.post(UrlConstants.AUTH_LOGIN, logincredentials);

  }
}
