import { Injectable } from '@angular/core';
// import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})
export class AppToastrService {

  constructor(
   // private _appToastrService: ToastrService
    ) { }

  showSuccess(message: string, title: string) {
   // this._appToastrService.success(message, title);
  }

  showError(message: string, title: string) {
  //  this._appToastrService.error(message, title);
  }

  ShowWarning() {
   // this._appToastrService.warning('warning', 'warning');
  }

  ShowInfo() {
  // this._appToastrService.info('info', 'info');
  }
}
