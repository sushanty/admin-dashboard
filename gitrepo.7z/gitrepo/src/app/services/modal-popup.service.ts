import { Injectable, TemplateRef } from '@angular/core';
//import {BsModalRef, BsModalService} from 'ngx-bootstrap';

@Injectable({
  providedIn: 'root'
})
export class ModalPopupService {
//modalRef: BsModalRef;

  constructor(
  //  private modalService: BsModalService
  ) { }

  popWithSize(content: TemplateRef<any>, size: string, backdrop?: boolean) {

    const config = {
      backdrop: true,
      ignoreBackdropClick : true
    };

    // this.modalRef = this.modalService.show(content, Object.assign({}, {
    //     class : 'grey modal-' + size,
    //     config: config
    //   }));

  }

  closeModal() {
 //   this.modalRef.hide();
  }


  }

