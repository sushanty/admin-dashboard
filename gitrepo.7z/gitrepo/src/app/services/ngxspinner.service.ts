import { Injectable, OnInit } from '@angular/core';
import {NgxSpinnerService} from 'ngx-spinner';

@Injectable({
  providedIn: 'root'
})
export class NgxspinnerService implements OnInit {
  constructor(private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    
  }

  show() {
    this.spinner.show();
  }

  hide() {
    this.spinner.hide();
  }
}
