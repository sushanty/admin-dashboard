import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AppConstants, RouterConstants, UrlConstants } from '../shared/Constants/constants';
import { HttpClient, HttpRequest } from '@angular/common/http';
import { TokenModel } from '../home/Modals/token.model';
import { Observable } from 'rxjs';
import { NEXT } from '@angular/core/src/render3/interfaces/view';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
tokeninfo: TokenModel;
cachedRequests: Array<HttpRequest<any>> = [];

  constructor(private _router: Router, private _http: HttpClient) { }

  saveAccessToken(data: any) {
    localStorage.setItem(AppConstants.ACCESS_TOKEN, data);
  }

  saveRefreshToken(data: any) {
    localStorage.setItem(AppConstants.REFRESH_TOKEN, JSON.stringify(data));
  }
  getToken(): any {
    // tslint:disable-next-line:max-line-length
    let token: string = localStorage.getItem(AppConstants.ACCESS_TOKEN) != null ?  localStorage.getItem(AppConstants.ACCESS_TOKEN).replace('"', '') : '';      
    token = token != null ? token.replace('"', '') : '';
    console.log('interceptor token: ' + token);
    return token;
   
  }

  getRefreshToken(): any {
     // tslint:disable-next-line:max-line-length
     let refreshtoken: string = localStorage.getItem(AppConstants.REFRESH_TOKEN) != null ?  localStorage.getItem(AppConstants.REFRESH_TOKEN).replace('"', '') : '';      
     refreshtoken = refreshtoken != null ? refreshtoken.replace('"', '') : '';
     console.log('refresh token: ' + refreshtoken);
     return refreshtoken;
    
  }

  removeAccessToken() {
    localStorage.removeItem(AppConstants.ACCESS_TOKEN);
  }

  removeRefreshToken() {
    localStorage.removeItem(AppConstants.REFRESH_TOKEN);
  }
  renewExpiredToken() {
   
      this.tokeninfo = {'accessToken': this.getToken(), 'refreshToken': this.getRefreshToken()};
      return this._http.post(UrlConstants.GET_RENEWED_ACCESS_TOKEN, this.tokeninfo);
  }

  isAuthenticated() {

  }

  tokenNotExpired() {

  }

  redirectToLogin() {
    this._router.navigate([RouterConstants.LOGIN]);
  }

  lastunauthorizedrequest() {

  }

  public collectFailedRequest(request): void {
   // this.cachedRequests.push(request);
    localStorage.setItem('failedrequest', request);
  }

  // public retryFailedRequests(): void {
  //   // retry the requests. this method can
  //   // be called after the token is refreshed
  //   // tslint:disable-next-line:no-unused-expression
  //   const req = this.cachedRequests.pop();
    
  //   console.log('failed request retrieved:' + this.cachedRequests.pop());
  // }

 // public getFailedRequest(): HttpRequest<any> {
   // alert('cached request:' + this.cachedRequests);
    // if (typeof this.cachedRequests !== 'undefined' && this.cachedRequests.length > 0) {
    //   return  this.cachedRequests.pop();
    // } else {
    //   return null;
    // }

  // return localStorage.getItem('failedrequest');
  //}
}
