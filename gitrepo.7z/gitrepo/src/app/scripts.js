$(document).ready(function(){
$(".sideMenuToggler").on("click", function(){
    $(".wrapper").toggleClass("active");
})
});