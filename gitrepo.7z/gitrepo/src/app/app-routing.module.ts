import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { componentFactoryName } from '@angular/compiler';
import {LoginComponent} from './Pages/login/login.component';
import { SignupComponent } from './Pages/signup/signup.component';
import { ForgotpasswordComponent } from './Pages/forgotpassword/forgotpassword.component';
import { NotfoundComponent } from './Pages/notfound/notfound.component';


const routes: Routes = [
  {
    path: '', component: LoginComponent, data: {title: 'Login Page'}
  },
  {
    path: 'login', component: LoginComponent, data: {title: 'Login Page'}
  },
  {
    path: 'signup', component : SignupComponent, data: {title: 'Sign Up'}
  },
  {
    path: 'forgotpassword', component : ForgotpasswordComponent, data: {title: 'Forgot Password'}
  }
  ,
  {
    path: 'home', loadChildren: './home/home.module#HomeModule'
  },
  {
    path: '**', component : NotfoundComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
