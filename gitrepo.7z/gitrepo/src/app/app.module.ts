import { BrowserModule } from '@angular/platform-browser';
 import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';

import {ReactiveFormsModule, FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { AppComponent } from './app.component';
import { LoginComponent } from './Pages/login/login.component';
import { SignupComponent } from './Pages/signup/signup.component';
import { ForgotpasswordComponent } from './Pages/forgotpassword/forgotpassword.component';
import { NotfoundComponent } from './Pages/notfound/notfound.component';


import {HttpErrorInterceptor} from './shared/Common/error-handler';

import { TokenInterceptor } from './shared/Common/token-interceptor';
 import {AuthService} from './services/auth.service';
 import { NgbDate, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RegistermodalpopupComponent } from './Modals/registermodalpopup/registermodalpopup.component';
import { ResetpasswordmodalpopupComponent } from './Modals/resetpasswordmodalpopup/resetpasswordmodalpopup.component';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

import { NgxSpinnerModule } from 'ngx-spinner';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    ForgotpasswordComponent,
    NotfoundComponent,
   
    RegistermodalpopupComponent,
    ResetpasswordmodalpopupComponent
   

  ],
  imports: [
    BrowserModule,   
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,  
    HttpClientModule,
    PerfectScrollbarModule,
    NgxSpinnerModule,
    
    NgbModule.forRoot(),   

    AppRoutingModule
  ],
  exports: [
   // NgbdatepickertemplateComponent
  ],
  schemas: [NO_ERRORS_SCHEMA],
  providers: [
    // {
    //   provide: HTTP_INTERCEPTORS,
    //   useClass: HttpErrorInterceptor,
    //   multi: true
    // },
    // {
    //   provide: HTTP_INTERCEPTORS,
    //   useClass: TokenInterceptor,
    //   multi: true
    // },
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ],
  entryComponents: [RegistermodalpopupComponent, ResetpasswordmodalpopupComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
