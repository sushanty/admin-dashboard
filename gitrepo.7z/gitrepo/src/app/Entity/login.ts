export class Login {
    public loginID: string;
    public password: string;
}
