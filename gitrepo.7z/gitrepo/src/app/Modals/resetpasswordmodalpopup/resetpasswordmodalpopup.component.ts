import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-resetpasswordmodalpopup',
  templateUrl: './resetpasswordmodalpopup.component.html',
  styleUrls: ['./resetpasswordmodalpopup.component.scss']
})
export class ResetpasswordmodalpopupComponent implements OnInit {
  @Input() name;
  constructor(public activeModal: NgbActiveModal) { }

  ngOnInit() {
    
  }

  onResetPassword() {
    alert('reset done!')
  }

}
