import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResetpasswordmodalpopupComponent } from './resetpasswordmodalpopup.component';

describe('ResetpasswordmodalpopupComponent', () => {
  let component: ResetpasswordmodalpopupComponent;
  let fixture: ComponentFixture<ResetpasswordmodalpopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResetpasswordmodalpopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResetpasswordmodalpopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
