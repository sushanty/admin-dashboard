import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-registermodalpopup',
  templateUrl: './registermodalpopup.component.html',
  styleUrls: ['./registermodalpopup.component.scss']
})
export class RegistermodalpopupComponent implements OnInit {
  @Input() name;
  constructor(public activeModal: NgbActiveModal) { }

  ngOnInit() {
  }

}
