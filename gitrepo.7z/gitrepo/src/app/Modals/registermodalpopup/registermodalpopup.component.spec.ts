import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistermodalpopupComponent } from './registermodalpopup.component';

describe('RegistermodalpopupComponent', () => {
  let component: RegistermodalpopupComponent;
  let fixture: ComponentFixture<RegistermodalpopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistermodalpopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistermodalpopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
