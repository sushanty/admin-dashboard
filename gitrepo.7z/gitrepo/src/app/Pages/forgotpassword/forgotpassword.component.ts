import { Component, OnInit } from '@angular/core';
import { ModalPopupService } from 'src/app/services/modal-popup.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { stringify } from '@angular/core/src/util';
import { AppConstants } from 'src/app/shared/Constants/constants';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.scss']
})
export class ForgotpasswordComponent implements OnInit {
  signupform: FormGroup;
  title: string;
  message: string;
  helptext: string;
  constructor(
    private  _modalService: ModalPopupService
  ) { }

  ngOnInit() {
    this.title = AppConstants.FORGOTPASSWORD_MODAL_TITLE;
  this.message = AppConstants.FORGOTPASSWORD_SUCCESS_MESSAGE;
  this.helptext = AppConstants.FORGOTPASSWORD_HELPTEXT;
  this.signupform = new FormGroup(
    {
      emailid: new FormControl('', [Validators.required])

    }
  );
  }

  close() {
    this._modalService.closeModal();
  }

}
