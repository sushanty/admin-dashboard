import { Component, OnInit } from '@angular/core';

import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ModalPopupService } from 'src/app/services/modal-popup.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  signupform: FormGroup;
  title: string;
  message: string;
  constructor(
    private _modalService: ModalPopupService
  ) { }

  ngOnInit() {
    this.title = 'Registration Form';
    this.message = 'Display your custom messages here';
    this.signupform = new FormGroup(
      {
        emailid: new FormControl('', [Validators.required]),
        mobilenumber: new FormControl('', [Validators.required])

      }
    );
  }

  close() {
    this._modalService.closeModal();
  }

}
