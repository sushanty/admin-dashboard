import { Component, OnInit, TemplateRef, Renderer2 } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { Login } from 'src/app/Entity/login';
import { LoaderService } from 'src/app/services/loader.service';
import { AuthService } from '../../services/auth.service';
import { AppConstants, RouterConstants } from 'src/app/shared/Constants/constants';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RegistermodalpopupComponent } from 'src/app/Modals/registermodalpopup/registermodalpopup.component';
import { ResetpasswordmodalpopupComponent } from 'src/app/Modals/resetpasswordmodalpopup/resetpasswordmodalpopup.component';
import {NgxspinnerService} from '../../services/ngxspinner.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
 

  loginform: FormGroup;
  invalidcredentialerrMsg = '';
  creds: Login;
  constructor(

    private modalService: NgbModal,
    private _loginservice: LoginService,
    private _router: Router,
   // private _loaderservice: LoaderService,
   // private _authservice: AuthService,
   private ngxspinner: NgxspinnerService,
    private renderer: Renderer2
  ) {
    this.renderer.setStyle(document.body, 'background-color', 'white');
  }

  ngOnInit() {
    this.loginform = new FormGroup(
      {
        loginname: new FormControl('', [
          Validators.required
        ]),
        password: new FormControl('', [
          Validators.required
        ])

      }
    );
    this.invalidcredentialerrMsg = '';
  }


  onLogin() {

  //  console.log(this.loginform.controls.loginname.value);
    const loginname = this.loginform.controls.loginname.value;
    const pwd = this.loginform.controls.password.value;
    this.creds = { 'loginID': loginname, 'password': pwd };
    this.ngxspinner.show();
    this._loginservice.login(this.creds).subscribe(data => {
      this.ngxspinner.hide();
      console.log('res: ' + JSON.stringify( data));
      this._router.navigate([RouterConstants.HOME]);
    },
      error => {
        this.ngxspinner.hide();
        console.log('error code::' + error.code);
      //  console.log('error message:' + error.message);
      this.invalidcredentialerrMsg = 'Invalid credential. Please enter correct LoginID/ Password.'
      });

      

   /** spinner starts on init */
  //  this.ngxspinner.show();
 
  //  setTimeout(() => {
  //      /** spinner ends after 5 seconds */
  //      this.ngxspinner.hide();
  //  }, 10000);
  }



  resetform(e,el) {
    this.loginform.reset();
    el.focus();
    this.invalidcredentialerrMsg = '';
  }
 
  OpenRegister() {
    const modalRef = this.modalService.open(RegistermodalpopupComponent);
    modalRef.componentInstance.name = 'World';
  }

  OpenResetPassword() {
    const modalRef = this.modalService.open(ResetpasswordmodalpopupComponent);
    modalRef.componentInstance.name = 'reset password';
  }

}
