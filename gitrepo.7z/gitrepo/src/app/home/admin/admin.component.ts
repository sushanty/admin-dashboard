import { Component, OnInit } from '@angular/core';
import { LoaderService } from '../../services/loader.service';
import { UsersService } from '../../services/users.service';

import { HttpErrorResponse, HttpRequest, HttpHandler } from '@angular/common/http';
import { AppToastrService } from '../../services/ToastrService/toastr.service';
import { ActivatedRoute, Router } from '@angular/router';
import { map, filter, switchMap } from 'rxjs/operators';
import { config } from 'rxjs';
import { ErrorResponse } from '../Modals/errorResponse.modal';
import swal from 'sweetalert';
import { AuthService } from '../../services/auth.service';
import { AppConstants } from '../../shared/Constants/constants';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
  userList: any;
  errorMsg: any;
  config: any;
  rowindex: any;
  page = 1;
  pageSize = 15;
  
  constructor(
    private _loaderservice: LoaderService,
    private _userservice: UsersService,
    private _toastrService: AppToastrService,
    private _authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) 
  {
    this.config = {
      currentPage: 1,
      itemsPerPage: 15
    };

  }

  ngOnInit() {
    //this.hideContent();
    this._loaderservice.showSpinner();
    // setTimeout(() => {
    let data: any;
    this._userservice.loadUsers()
      .subscribe(res => {
        data = res;
     //   this.showContent();
        this.userList = data;
      },
        error => {
         // this.errorMsg = error.statusCode;
          if (error.statusCode === 401) {
           // this._toastrService.showError('Data not fetched.', 'Error:');
           
          //  swal({
          //         title: 'Token expired!',
          //         text: 'Click ok to refresh the token to continue.',
          //         icon: 'warning'
          // })
          // .then((willRefresh) => {
          //   if (willRefresh) {
          //     // swal('Token is refreshed. ', {
          //     //   icon: 'success',
          //     // });
          //     this._authService.renewExpiredToken().subscribe(res => {
          //       console.log('new access token:' + res[AppConstants.ACCESS_TOKEN]);
          //       console.log('new refresh token:' + res[AppConstants.REFRESH_TOKEN]);
          //       if (res['accessToken'] !== '') {
          //         this._authService.saveRefreshToken(res[AppConstants.REFRESH_TOKEN]);
          //         this._toastrService.showSuccess('Token refreshed', '');
          //       }
          //     });
          //   } else {
          //     swal('Token is not refreshed. Please log in again to continue.');
          //   }
          // });
          }
        }
      );
    this._loaderservice.hideSpinner();
    // }, 5000);
    this.rowindex = this.config.itemsPerPage * (this.config.currentPage - 1);
  }

  getPageSymbol(current: number) {
    return ['A', 'B', 'C', 'D', 'E', 'F', 'G'][current - 1];
  }
  pageChange(newPage: number) {
    this.config.currentPage = newPage;
    this.rowindex = this.config.itemsPerPage * (this.config.currentPage - 1);

  }

 

  // hideContent() {
  //   $('#tableadmin').css('display', 'none');
  // }
  // showContent() {
  //   $('#tableadmin').css('display', 'block');
  // }

}
