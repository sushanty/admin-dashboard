import { Component, OnInit } from '@angular/core';
import {NgbCalendar, NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import swal from 'sweetalert';


@Component({
  selector: 'app-createuser',
  templateUrl: './createuser.component.html',
  styleUrls: ['./createuser.component.scss']
})
export class CreateuserComponent implements OnInit {
  model: NgbDateStruct;
  today = this.calendar.getToday();
  
  constructor(private calendar: NgbCalendar) { }

  ngOnInit() {
  }
  onSubmit() {
    swal({
                  title: 'Submit.',
                  text: 'You clicked submit button.',
                  icon: 'success'
          });

  }

  
  onCancel() {
    swal({
                  title: 'Cancel.',
                  text: 'You clicked cancel button.',
                  icon: 'error'
          });

  }

}
