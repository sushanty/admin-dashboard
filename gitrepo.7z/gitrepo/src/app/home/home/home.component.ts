import { Component, OnInit, Renderer2 } from '@angular/core';
import { LoaderService } from '../../services/loader.service';
import { HeaderComponent } from '../header/header.component';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements OnInit {
  
  imagePath: any;
  istoggled: false;
  constructor(
    private _loaderService: LoaderService,
    private _router: Router,
    private _authService: AuthService,
    private renderer: Renderer2
  ) { this.renderer.setStyle(document.body, 'background-color', '#F1F1F1'); }

  ngOnInit() {

    this.imagePath = 'assets/Sushant_Yadav.JPG';

    $(document).ready(function () {
      
      $('.sideMenuToggler').on('click', function() {
        $('.wrapper').toggleClass('active');
        // $('.sideMenu').css('width', '50px')
        // $('.content').css('margin-left', '50px')

    });

   

 

    });



  




  }
  showMenu() {
    // alert('i am cliked');
  }
  onlogout() {
    this._authService.removeRefreshToken();
    this._authService.removeAccessToken();
    this._router.navigate(['login']);
  }

  navbarToggler() {
   // $('#sidenavId').toggleClass('visible');
    // document.getElementById(' sidenavId ').classList.toggle('visible');
  }

  // toggle(e) {
  //   $(document).ready(function(event) {
  //   // alert('toggle is clicked' + e.target.id);
  //  // event.preventDefault();
  //     $('#wrapper').toggleClass('menuDisplayed');
  //   });
  //   }


}
