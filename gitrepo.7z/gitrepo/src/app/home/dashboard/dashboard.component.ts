import { Component, OnInit } from '@angular/core';
import {LoaderService} from '../../services/loader.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor(
    private _loaderService: LoaderService
  ) { }

  ngOnInit() {
    this._loaderService.showSpinner();
    // setTimeout(() => {
      this._loaderService.hideSpinner();
    // }, 1000);

   // "2012-02-10T13:19:11+0000"
   //1524757879000
const date = new Date('2012-02-10T13:19:11+0000');
console.log('my date:' + date.getTime());
//alert('my date' + date.getTime());
//alert(new Date(1524757879000).toUTCString());
  }

}
