import { Component, OnInit } from '@angular/core';
import {LoaderService} from '../../services/loader.service';
import { checkAndUpdateBinding } from '@angular/core/src/view/util';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {

  constructor(
    private _loaderService: LoaderService
  ) { }

  ngOnInit() {
    // this._loaderService.showSpinner();
    // setTimeout(() => {
    //   this._loaderService.hideSpinner();
    // }, 2000);

    // tslint:disable-next-line:prefer-const
    let myArray = [
      {id: 1, name: 'Foo Bar', email: 'foo@bar.com'},
      {id: 1, name: 'Bar Foo', email: 'bar@foo.com'},
      {id: 3, name: 'Joe Ocean', email: 'joe@ocean.com'},
      {id: 3, name: 'Jenny Block', email: 'foo@bar.com'},
    ];
    console.log( this.checkDuplicateInObject('id', myArray));
  }

  checkDuplicateInObject(propertyName, inputArray) {
    let seenDuplicate = false,
        // tslint:disable-next-line:prefer-const
        testObject = {};
        // tslint:disable-next-line:no-var-keyword
        var myarr = [];
  
    inputArray.map(function(item) {
      // tslint:disable-next-line:prefer-const
      let itemPropertyName = item[propertyName];
      if (itemPropertyName in testObject) {
        testObject[itemPropertyName].duplicate = true;
        item['isduplicate'] = true;
     myarr.push( item);
        seenDuplicate = true;
      } else {
        testObject[itemPropertyName] = item;
        delete item.duplicate;
      }
    });

    return myarr;
  }

}
