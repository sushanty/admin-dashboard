import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UrlConstants } from 'src/app/shared/Constants/constants';
import * as $ from 'jquery';


@Component({
  // selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  constructor(private _http:HttpClient) { }
  ngOnInit() {

    $(document).ready(function () {
    

    });
this._http.get(UrlConstants.Login_getUsers).subscribe(data => {
  console.log('login users: ' + JSON.stringify( data));
})


  }

}
