import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms';

// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SettingsComponent } from './settings/settings.component';
import { AdminComponent } from './admin/admin.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidebarComponent } from './sidebar/sidebar.component';

import { CreateuserComponent } from './createuser/createuser.component';
import { NgbDate, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UsersComponent } from './users/users.component';
import { ProjectsComponent } from './projects/projects.component';
import { ClientsComponent } from './clients/clients.component';


import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';

import { NgxSpinnerModule } from 'ngx-spinner';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

@NgModule({
  declarations: [
    HomeComponent,
    DashboardComponent,
    SettingsComponent,
    AdminComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    CreateuserComponent,
    UsersComponent,
    ProjectsComponent,
    ClientsComponent

  ],
  imports: [
    CommonModule,

   // ToastrModule.forRoot(),
    HomeRoutingModule,
    FormsModule,
    PerfectScrollbarModule,
    NgbModule,
    NgxSpinnerModule
  ]
})
export class HomeModule { }
