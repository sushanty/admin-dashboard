export class ErrorResponse {
    public statusCode: number;
    public message: string;
}
