export class Users {
    userId: string;
    firstName: string;
    lastName: string;
    address: string;
    pwd: any;
}
