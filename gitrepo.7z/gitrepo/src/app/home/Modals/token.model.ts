export class TokenModel {
    accessToken: string;
    refreshToken: string;
}
